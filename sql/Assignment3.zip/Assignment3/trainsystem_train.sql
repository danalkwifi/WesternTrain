-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: trainsystem
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `train`
--

DROP TABLE IF EXISTS `train`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `train` (
  `trainNo` int NOT NULL,
  `isPetFriendly` varchar(3) NOT NULL DEFAULT 'yes',
  `isAccessible` varchar(3) NOT NULL DEFAULT 'yes',
  `lineColor` varchar(10) NOT NULL,
  PRIMARY KEY (`trainNo`),
  KEY `fk_lineColor` (`lineColor`),
  CONSTRAINT `fk_lineColor` FOREIGN KEY (`lineColor`) REFERENCES `line` (`lineColor`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `train_chk_1` CHECK ((`isPetFriendly` in (_utf8mb4'yes',_utf8mb4'no'))),
  CONSTRAINT `train_chk_2` CHECK ((`isAccessible` in (_utf8mb4'yes',_utf8mb4'no')))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `train`
--

LOCK TABLES `train` WRITE;
/*!40000 ALTER TABLE `train` DISABLE KEYS */;
INSERT INTO `train` VALUES (1,'Yes','Yes','yellow'),(2,'Yes','Yes','orange'),(3,'No','Yes','red'),(4,'No','Yes','red'),(5,'Yes','No','red'),(6,'No','No','red'),(7,'Yes','No','red'),(8,'Yes','Yes','red'),(9,'Yes','Yes','red'),(10,'Yes','No','red'),(11,'Yes','Yes','blue'),(12,'Yes','No','orange'),(13,'No','No','orange'),(14,'Yes','No','blue'),(15,'Yes','No','yellow'),(16,'Yes','No','blue'),(17,'No','Yes','orange'),(18,'Yes','Yes','yellow'),(19,'No','No','blue'),(20,'No','No','yellow'),(21,'No','No','red'),(22,'No','Yes','blue'),(23,'Yes','Yes','blue'),(24,'Yes','No','red'),(25,'No','No','yellow');
/*!40000 ALTER TABLE `train` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-26 16:34:22
