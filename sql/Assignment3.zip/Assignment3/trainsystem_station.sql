-- MySQL dump 10.13  Distrib 8.0.27, for Win64 (x86_64)
--
-- Host: localhost    Database: trainsystem
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `station`
--

DROP TABLE IF EXISTS `station`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `station` (
  `stationNo` int NOT NULL,
  `stationName` varchar(100) NOT NULL,
  `streetNum` int NOT NULL,
  `streetName` varchar(100) NOT NULL,
  PRIMARY KEY (`stationNo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `station`
--

LOCK TABLES `station` WRITE;
/*!40000 ALTER TABLE `station` DISABLE KEYS */;
INSERT INTO `station` VALUES (1,'Station Henri-Bourassa',1515,'Pond Junction'),(2,'Station Sauvé',3439,'Morning Road'),(3,'Station Crémazie',2483,'Washington Avenue'),(4,'Station Jarry',6091,'Darwin Point'),(5,'Station Jean-Talon',2790,'Corben Trail'),(6,'Station Beaubien',4314,'Morrow Trail'),(7,'Station Rosemont',1378,'Northview Circle'),(8,'Station Laurier',2888,'Kensington Center'),(9,'Station Mont-Royal',5074,'Johnson Circle'),(10,'Station Sherbrooke',4545,'Larry Trail'),(11,'Station Champs-de-Mars',1419,'Shasta Street'),(12,'Station Place-d\'Armes',8623,'Waywood Court'),(13,'Station Square-Victoria',2050,'Fremont Circle'),(14,'Station Bonaventure',2155,'Manufacturers Junction'),(15,'Station Lucian-L\'Allier',1327,'Surrey Park'),(16,'Station George-Vanier',2178,'Hagan Terrace'),(17,'Station Place-Saint-Henri',5957,'Dexter Road'),(18,'Station Vedome',3976,'Heffernan Plaza'),(19,'Station Villa-Maria',7311,'Monica Pass'),(20,'Station Snowdon',3640,'Kings Way'),(21,'Station Cote-Sainte-Catherine',2381,'Hagan Center'),(22,'Station Plamondon',9280,'Algoma Place'),(23,'Station Namur',5985,'Packers Road'),(24,'Station de la Savane',8012,'Brentwood Way'),(25,'Station du Collége',3303,'Bultman Alley'),(26,'Station Cote-Vertue',1885,'Golf Course Crossing'),(27,'Station Cote-de-Neiges',1855,'Lakewood Gardens Way'),(28,'Station Université-de-Montréal',4231,'Porter Drive'),(29,'Station Édouard-Montpetit',2575,'Basil Park'),(30,'Station Outremont',6534,'Spenser Trail'),(31,'Station Acadie',7250,'Packers Place'),(32,'Station Parc',4055,'6th Plaza'),(33,'Station de Castelnau',7165,'Moulton Plaza'),(34,'Station Fabre',9763,'Thompson Parkway'),(35,'Station D\'lberville',6256,'Forster Point'),(36,'Station Saint-Michel',4714,'Melrose Street'),(37,'Station Longueuli',3208,'Forest Hill'),(38,'Station Jean-Drapeau',5601,'Homewood Plaza'),(39,'Station Cherbourg',3633,'Sycamore Junction'),(40,'Station Nancy-Ville',3396,'Mariners Cove Street'),(41,'Station Honoré-Beaugrand',9750,'Mallard Pass'),(42,'Station Radisson',6869,'Dottie Court'),(43,'Station Langelier',2440,'Sherman Center'),(44,'Station Cadillac',6110,'Gateway Way'),(45,'Station Assomption',6275,'Havey Terrace'),(46,'Station Pie-IX',6336,'Mayfield Park'),(47,'Station Joliette',2730,'Cardinal Crossing'),(48,'Station Préfontaine',3165,'Stone Corner Park'),(49,'Station Frontenac',8802,'Crescent Oaks Crossing'),(50,'Station Papineau',8691,'Moulton Trail'),(51,'Station Beaudry',7159,'Hermina Pass'),(52,'Station Berri-UQAM',9095,'Melrose Road'),(53,'Station Place des Arts',3676,'Drewry Junction'),(54,'Station McGill',3526,'Heath Trail'),(55,'Station Peel',1182,'Amoth Terrace'),(56,'Station Guy-Concordia',9154,'Crownhardt Plaza'),(57,'Station Atwater',2963,'Bunker Hill Court'),(58,'Station Lionel-Groulx',3933,'Spenser Terrace'),(59,'Station Charlevoix',7493,'Forster Lane'),(60,'Station LaSalle',2398,'Morrow Road'),(61,'Station de l\'Église',9381,'Barnett Avenue'),(62,'Station Verdun',6769,'Nova Park'),(63,'Station Jolicoeur',7872,'La Follette Hill'),(64,'Station Monk',8918,'Prairie Rose Pass'),(65,'Station Angrignon',1769,'Talisman Park'),(66,'Station de Layon',2133,'Bayside Court'),(67,'Station de l\'Est',8236,'Helena Drive'),(68,'Station de Bercy',4234,'3rd Place'),(69,'Statin d\'Austerlitz',9377,'Elmside Terrace'),(70,'Station Montparnasses',5372,'Portage Court'),(71,'Station Saint-Lazare',1542,'Lakeland Parkway'),(72,'Station du Norde',4038,'Ridgeview Junction'),(73,'Station Magenta',3379,'Bluestem Way'),(74,'Station d\'Arras',4063,'Prairieview Center'),(75,'Station Beanue',7314,'Westport Point'),(76,'Station Saint-Jean',6174,'Jenifer Way'),(77,'Station de Matz',4473,'Messerschmidt Crossing'),(78,'Station de Lyon',1917,'Graceland Alley'),(79,'Station Poitiers',1657,'Claremont Way'),(80,'Station Lille Europe',8547,'Cody Crossing'),(81,'Station de Grenoble',9068,'Forest Street'),(82,'Station Charles',7417,'Rockefeller Park'),(83,'Station Lille-Flandres',1144,'Debra Plaza'),(84,'Station de Lourdes',9477,'Killdeer Hill'),(85,'Station Bordeaux',5887,'Mcguire Way'),(86,'Station les Halles',1742,'Bunting Road'),(87,'Station Luxembourg',7327,'Harbort Drive'),(88,'Station Saint-Laud',5002,'Parkside Pass'),(89,'Station Canfranc',3906,'Gina Avenue'),(90,'Station Auber',4103,'Thompson Junction'),(91,'Station le Verriére',2314,'Red Cloud Road'),(92,'Station de Tulle',9140,'Cambridge Court'),(93,'Station de Bayeux',5468,'Loftsgordon Avenue'),(94,'Station Austerlitz',1507,'Dakota Lane'),(95,'Station d\'Orléans',6976,'Stang Parkway'),(96,'Station Biarritz',3997,'Longview Terrace'),(97,'Station de Bayonne',3017,'Rutledge Avenue'),(98,'Station la Ciotat',5329,'Lakeland Junction'),(99,'Station d\'Avranches',9551,'Schurz Road'),(100,'Station de Vaires Torcy',7153,'Golf View Center');
/*!40000 ALTER TABLE `station` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-26 16:34:34
